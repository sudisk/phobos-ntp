# phobos-ntp
Puppet module for configure ntp
